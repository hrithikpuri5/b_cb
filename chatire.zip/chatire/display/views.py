from django.shortcuts import render
from django.http import HttpResponse
import requests

def home(request):

    # response = requests.get('http://localhost:8000/api/req')
    # reply = response.json()
    # context = {
   	# 	'data' : reply,
   	# 	    }

    # return render(request, 'home.html', context)
    return render(request, 'home.html')
