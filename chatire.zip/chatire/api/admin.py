from django.contrib import admin
from .models import ChatMessage
from import_export import resources

admin.site.register(ChatMessage)

class BookResource(resources.ModelResource):

    class Meta:
        model = ChatMessage
