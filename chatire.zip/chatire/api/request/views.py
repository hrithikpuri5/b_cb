from rest_framework import generics,mixins
from api.models import ChatMessage
from .serializers import SendTextSerializer
from .permissions import IsOwnerOrReadOnly
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords

class send_text(mixins.CreateModelMixin,generics.ListAPIView):
	lookup_field = 'pk'
	serializer_class = SendTextSerializer
	permission_classes = [IsOwnerOrReadOnly]
	def get_queryset(self):
		cachedStopWords = stopwords.words("english")
		qs = ChatMessage.objects.all()
		query =  self.request.GET.get("q")
		lemmatiser = WordNetLemmatizer()
		query = ' '.join([lemmatiser.lemmatize(word, pos="v") for word in query.split() if word not in cachedStopWords])
		if query is not None:
			qs= qs.filter(text__icontains=query)
		return qs