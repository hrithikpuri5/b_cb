from rest_framework import serializers
from api.models import ChatMessage

class SendTextSerializer(serializers.ModelSerializer): #convert to json
	class Meta:
		model = ChatMessage
		fields = [
			'text',
			'response',
		]
		read_only = ['text','response']