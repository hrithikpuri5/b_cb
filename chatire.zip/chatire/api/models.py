from django.db import models
from django.contrib.auth.models import User


class ChatRoom(models.Model):
    eid = models.CharField(max_length=64, unique=True)
    
class ChatMessage(models.Model):
    date = models.DateTimeField(auto_now=True, db_index=True)
    text = models.TextField()   
    response = models.TextField(default='none')

    def __str__(self):
        return self.text

    @property
    def owner(self):
    	return self.user